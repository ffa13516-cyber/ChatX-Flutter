import 'package:flutter/material.dart';
import 'package:grouped_list/grouped_list.dart';

class CodiaPage extends StatefulWidget {
  CodiaPage({super.key});

  @override
  State<StatefulWidget> createState() => _CodiaPage();
}

class _CodiaPage extends State<CodiaPage> {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.white,
      child: Container(
        height: 1280,
        decoration: BoxDecoration(
          color: const Color(0x00000000),
        ),
        child: Stack(
          children: [
            Positioned(
              right: 0,
              width: 605,
              bottom: 0,
              height: 1280,
              child: Image.asset('images/image1_466.png', width: 605, height: 1280, fit: BoxFit.cover,),
            ),
            Positioned(
              right: 11,
              width: 591,
              bottom: 3,
              height: 1196,
              child: Container(
                width: 591,
                height: 1196,
                decoration: BoxDecoration(
                  color: const Color(0x00000000),
                ),
                child: Stack(
                  children: [
                    Positioned(
                      right: 23,
                      width: 175,
                      bottom: 5,
                      height: 202,
                      child: Image.asset('images/image_468.png', width: 175, height: 202,),
                    ),
                    Positioned(
                      right: 0,
                      width: 591,
                      bottom: 141,
                      height: 1055,
                      child: Container(
                        width: 591,
                        height: 1055,
                        decoration: BoxDecoration(
                          color: const Color(0x00000000),
                        ),
                        child: Stack(
                          children: [
                            Positioned(
                              right: 22,
                              width: 546,
                              bottom: 73,
                              height: 124,
                              child: Image.asset('images/image1_4612.png', width: 546, height: 124,),
                            ),
                            Positioned(
                              right: 72,
                              width: 446,
                              bottom: 216,
                              height: 121,
                              child: Container(
                                width: 446,
                                height: 121,
                                decoration: BoxDecoration(
                                  color: const Color(0x00000000),
                                ),
                                child: Stack(
                                  children: [
                                    Positioned(
                                      right: 0,
                                      width: 224,
                                      bottom: 0,
                                      height: 118,
                                      child: Container(
                                        width: 224,
                                        height: 118,
                                        decoration: BoxDecoration(
                                          color: const Color(0x00000000),
                                        ),
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              right: 26,
                                              width: 168,
                                              bottom: 7,
                                              height: 29,
                                              child: Text(
                                                'Mutual Groups',
                                                textAlign: TextAlign.left,
                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 23, color: const Color(0xff52565e), fontWeight: FontWeight.normal),
                                                maxLines: 9999,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                            Positioned(
                                              right: 29,
                                              width: 164,
                                              bottom: 51,
                                              height: 56,
                                              child: Image.asset('images/image1_4620.png', width: 164, height: 56, fit: BoxFit.cover,),
                                            ),
                                            Positioned(
                                              right: 46,
                                              width: 24,
                                              bottom: 71,
                                              height: 15,
                                              child: Image.asset('images/image2_4621.png', width: 24, height: 15, fit: BoxFit.cover,),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      right: 227,
                                      width: 219,
                                      bottom: 1,
                                      height: 120,
                                      child: Container(
                                        width: 219,
                                        height: 120,
                                        decoration: BoxDecoration(
                                          color: const Color(0x00000000),
                                        ),
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              right: 34,
                                              width: 144,
                                              bottom: 7,
                                              child: Text(
                                                'Friends Flow',
                                                textAlign: TextAlign.left,
                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 23, color: const Color(0xff51555d), fontWeight: FontWeight.normal),
                                                maxLines: 9999,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                            Positioned(
                                              right: 27,
                                              width: 164,
                                              bottom: 49,
                                              height: 57,
                                              child: Image.asset('images/image_4624.png', width: 164, height: 57, fit: BoxFit.cover,),
                                            ),
                                            Positioned(
                                              right: 35,
                                              width: 38,
                                              bottom: 67,
                                              height: 21,
                                              child: Text(
                                                '+123',
                                                textAlign: TextAlign.left,
                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 15, color: const Color(0xff4e565f), fontWeight: FontWeight.normal),
                                                maxLines: 9999,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              right: 100,
                              width: 389,
                              bottom: 353,
                              height: 73,
                              child: Container(
                                width: 389,
                                height: 73,
                                decoration: BoxDecoration(
                                  color: const Color(0x00000000),
                                ),
                                child: Stack(
                                  children: [
                                    Positioned(
                                      right: 0,
                                      width: 113,
                                      bottom: 5,
                                      height: 64,
                                      child: Image.asset('images/image1_4627.png', width: 113, height: 64, fit: BoxFit.cover,),
                                    ),
                                    Positioned(
                                      right: 119,
                                      width: 152,
                                      bottom: 0,
                                      height: 73,
                                      child: Container(
                                        width: 152,
                                        height: 73,
                                        decoration: BoxDecoration(
                                          color: const Color(0x00000000),
                                        ),
                                        child: Stack(
                                          children: [
                                            Positioned(
                                              right: 4,
                                              width: 143,
                                              bottom: 4,
                                              height: 66,
                                              child: Image.asset('images/image_4629.png', width: 143, height: 66, fit: BoxFit.cover,),
                                            ),
                                            Positioned(
                                              right: 28,
                                              width: 93,
                                              bottom: 22,
                                              height: 27,
                                              child: Text(
                                                'Messoge',
                                                textAlign: TextAlign.left,
                                                style: TextStyle(decoration: TextDecoration.none, fontSize: 21, color: const Color(0xff8dacec), fontWeight: FontWeight.normal),
                                                maxLines: 9999,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      right: 276,
                                      width: 113,
                                      bottom: 5,
                                      height: 64,
                                      child: Image.asset('images/image2_4631.png', width: 113, height: 64, fit: BoxFit.cover,),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Positioned(
                              right: 45,
                              width: 500,
                              bottom: 458,
                              height: 65,
                              child: Text(
                                'I\'m a generous and girl, hope my enthusiasm\nadd more color to your life... More',
                                textAlign: TextAlign.center,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 23, color: const Color(0xff363a44), fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Positioned(
                              right: 249,
                              width: 68,
                              bottom: 550,
                              child: Text(
                                'Online',
                                textAlign: TextAlign.left,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 21, color: const Color(0xff1b5421), fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Positioned(
                              right: 323,
                              width: 14,
                              bottom: 554,
                              height: 14,
                              child: Image.asset('images/image2_4634.png', width: 14, height: 14, fit: BoxFit.cover,),
                            ),
                            Positioned(
                              right: 168,
                              width: 33,
                              bottom: 593,
                              height: 34,
                              child: Image.asset('images/image3_4635.png', width: 33, height: 34, fit: BoxFit.cover,),
                            ),
                            Positioned(
                              right: 210,
                              width: 210,
                              bottom: 591,
                              height: 36,
                              child: Text(
                                'Kristin Watson',
                                textAlign: TextAlign.left,
                                style: TextStyle(decoration: TextDecoration.none, fontSize: 29, color: const Color(0xff7f8286), fontWeight: FontWeight.normal),
                                maxLines: 9999,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ),
                            Positioned(
                              right: 189,
                              width: 210,
                              bottom: 653,
                              height: 383,
                              child: Image.asset('images/image4_4637.png', width: 210, height: 383, fit: BoxFit.cover,),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              right: 67,
              width: 33,
              bottom: 1219,
              height: 18,
              child: Image.asset('images/image2_4638.png', width: 33, height: 18, fit: BoxFit.cover,),
            ),
            Positioned(
              right: 113,
              width: 25,
              bottom: 1219,
              height: 18,
              child: Image.asset('images/image3_4639.png', width: 25, height: 18, fit: BoxFit.cover,),
            ),
            Positioned(
              right: 147,
              width: 30,
              bottom: 1218,
              height: 20,
              child: Image.asset('images/image4_4640.png', width: 30, height: 20, fit: BoxFit.cover,),
            ),
            Positioned(
              right: 492,
              width: 54,
              bottom: 1213,
              height: 31,
              child: Text(
                '9c41',
                textAlign: TextAlign.left,
                style: TextStyle(decoration: TextDecoration.none, fontSize: 22, color: const Color(0xff6a7684), fontWeight: FontWeight.normal),
                maxLines: 9999,
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
